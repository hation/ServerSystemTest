#!/bin/bash
# ============================================================
# check-nvme-health.sh — NVMe 故障盘一键健康检查（只读）
# 适用：Kylin/KySec（麒麟）服务器，root 或 sudo 直接执行
# 用法：bash check-nvme-health.sh             # 默认检查 nvme2n1
#       bash check-nvme-health.sh nvme0n1     # 指定设备（自动补 nvme 前缀）
# 说明：本脚本只做只读检查，不执行修复/卸载/格式化；
#       fsck、短自检（smartctl -t short）仅给出提示，不自动执行。
# ============================================================
set -u

# ---------- 参数解析 ----------
DEV="${1:-nvme2n1}"
case "$DEV" in
    nvme*) ;;
    *) DEV="nvme${DEV}" ;;
esac
DEVNODE="/dev/${DEV}"

# ---------- 颜色（非 tty 自动禁用） ----------
if [ -t 1 ]; then
    C_GREEN=$'\033[32m'
    C_RED=$'\033[31m'
    C_YELLOW=$'\033[33m'
    C_RESET=$'\033[0m'
else
    C_GREEN=''; C_RED=''; C_YELLOW=''; C_RESET=''
fi

# ---------- 工具可用性检测 ----------
have() { command -v "$1" >/dev/null 2>&1; }
HAS_SMARTCTL=0; HAS_NVME=0; HAS_DMESG=0
have smartctl && HAS_SMARTCTL=1
have nvme && HAS_NVME=1
have dmesg && HAS_DMESG=1

# ---------- 结论判定标志 ----------
critical=0      # SMART 严重字段命中计数（Critical Warning 非 0 / Media Errors>0 / Percentage Used>=100）
ioerr=0         # dmesg 命中 print_req_error / I/O error 计数
unavailable=0   # smartctl/nvme/dmesg 不可用计数（三者均不可用 -> 证据不足）

# ---------- 提取 smartctl 字段数值 ----------
# $1: smartctl 输出行；返回十进制数值（0x 转十进制、去 % 与千分位逗号，非数字回 0）
field_val() {
    local v
    v=$(printf '%s\n' "$1" | sed -n 's/^[^:]*:[[:space:]]*//p')
    case "$v" in
        *%*) v=${v%\%} ;;
    esac
    case "$v" in
        0[xX][0-9a-fA-F]*) v=$((v)) ;;
    esac
    v=$(printf '%s' "$v" | tr -d ',')
    case "$v" in
        ''|*[!0-9]*) v=0 ;;
    esac
    echo "$v"
}

echo "================================================================"
echo " NVMe 故障盘一键健康检查（只读）"
echo " 检查设备: ${DEV} (${DEVNODE})    时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "================================================================"

# ---------- [1/5] 设备基本信息 ----------
echo ""
echo "---------- [1/5] 设备基本信息 ----------"
if have lsblk; then
    lsblk -d -o NAME,SIZE,MODEL "${DEVNODE}" 2>&1
else
    echo "[提示] 未找到 lsblk 命令（util-linux），跳过设备信息。"
fi
if [ "$HAS_NVME" -eq 1 ]; then
    echo "-- nvme list --"
    nvme list 2>&1
else
    echo "[提示] 未安装 nvme-cli，跳过 nvme list 与厂商 smart-log 检查。"
    echo "        安装命令: yum install -y nvme-cli"
    unavailable=$((unavailable+1))
fi

# ---------- [2/5] SMART 健康 ----------
echo ""
echo "---------- [2/5] SMART 健康 (smartctl -a) ----------"
if [ "$HAS_SMARTCTL" -eq 1 ]; then
    out=$(smartctl -a "${DEVNODE}" 2>&1)
    rc=$?
    if [ "$rc" -ne 0 ]; then
        echo "$out"
        echo "[提示] smartctl 执行失败（可能无权限或设备不支持），SMART 项视为不可用。"
        unavailable=$((unavailable+1))
    else
        echo "-- smartctl -a 关键字段 --"
        printf '%s\n' "$out" | grep -iE "Critical Warning|Temperature:|Available Spare|Percentage Used|Media and Data Integrity|Error Information Log|Data Units Written"
        sm=$(printf '%s\n' "$out" | grep -i "Critical Warning" | head -1)
        if [ -n "$sm" ] && [ "$(field_val "$sm")" -ne 0 ]; then
            echo "[!!] 命中严重字段: ${sm}（Critical Warning 非 0）"
            critical=$((critical+1))
        fi
        sm=$(printf '%s\n' "$out" | grep -i "Media and Data Integrity" | head -1)
        if [ -n "$sm" ] && [ "$(field_val "$sm")" -gt 0 ]; then
            echo "[!!] 命中严重字段: ${sm}（Media and Data Integrity Errors > 0）"
            critical=$((critical+1))
        fi
        sm=$(printf '%s\n' "$out" | grep -i "Percentage Used" | head -1)
        if [ -n "$sm" ] && [ "$(field_val "$sm")" -ge 100 ]; then
            echo "[!!] 命中严重字段: ${sm}（Percentage Used >= 100%）"
            critical=$((critical+1))
        fi
        if [ "$critical" -eq 0 ]; then
            echo "(SMART 关键字段未见严重异常)"
        fi
    fi
else
    echo "[提示] 未安装 smartmontools，跳过 SMART 检查。"
    echo "        安装命令: yum install -y smartmontools"
    unavailable=$((unavailable+1))
fi

# ---------- [3/5] NVMe 厂商日志 ----------
echo ""
echo "---------- [3/5] NVMe 厂商日志 (nvme smart-log) ----------"
if [ "$HAS_NVME" -eq 1 ]; then
    nvme smart-log "${DEVNODE}" 2>&1
else
    echo "[提示] 未安装 nvme-cli，跳过（安装: yum install -y nvme-cli）。"
fi

# ---------- [4/5] 内核故障记录 ----------
echo ""
echo "---------- [4/5] 内核故障记录 (dmesg) ----------"
if [ "$HAS_DMESG" -eq 1 ]; then
    dmesg_out=$(dmesg -T 2>&1)
    rc=$?
    if [ "$rc" -ne 0 ]; then
        echo "$dmesg_out"
        echo "[提示] dmesg 读取失败（通常为权限不足），可用 sudo 重跑本脚本获取完整内核日志。"
        unavailable=$((unavailable+1))
    else
        hits=$(printf '%s\n' "$dmesg_out" | grep -iE "${DEV}|print_req_error|I/O error|Buffer I/O|EXT4-fs" | tail -40)
        if [ -n "$hits" ]; then
            printf '%s\n' "$hits"
        else
            echo "(内核日志中未见 ${DEV} 相关故障记录)"
        fi
        if printf '%s\n' "$dmesg_out" | grep -qiE "print_req_error|I/O error"; then
            echo "[!!] 命中内核 I/O 错误记录（print_req_error / I/O error），异常标志 +1"
            ioerr=$((ioerr+1))
        fi
    fi
else
    echo "[提示] 未找到 dmesg 命令，跳过内核故障记录检查。"
    unavailable=$((unavailable+1))
fi

# ---------- [5/5] 文件系统/挂载状态 ----------
echo ""
echo "---------- [5/5] 文件系统/挂载状态 ----------"
if have mount; then
    mount | grep "${DEV}" 2>&1 || echo "(mount 列表未见 ${DEV} 相关记录)"
else
    echo "[提示] 未找到 mount 命令，跳过挂载状态检查。"
fi
if have lsblk; then
    lsblk -o NAME,MOUNTPOINT,FSTYPE "${DEVNODE}" 2>&1
else
    echo "[提示] 未找到 lsblk 命令，跳过分区/文件系统信息检查。"
fi
if have mount && mount | grep -q "${DEV}"; then
    echo "[提示] ${DEV} 当前已挂载。如需执行短自检 smartctl -t short，建议先卸载；"
    echo "        fsck/自检等修复操作本脚本只给建议，不自动执行（只读检查）。"
else
    echo "[提示] ${DEV} 未挂载或无法确认。fsck / smartctl -t short 等修复/自检操作仅作建议，本脚本不自动执行（只读检查）。"
fi

# ---------- 结论判定 ----------
echo ""
echo "================================================================"
echo "                          结论判定"
echo "================================================================"
if [ "$critical" -gt 0 ] || [ "$ioerr" -gt 0 ]; then
    echo "${C_RED}判定：异常${C_RESET} — SMART 严重字段或内核 I/O 错误命中。"
    echo "      建议：更换/返修该盘，相关压测数据无效，需重测。"
elif [ "$unavailable" -ge 3 ]; then
    echo "${C_YELLOW}判定：证据不足${C_RESET} — smartctl/nvme/dmesg 均不可用，需 sudo 重跑。"
else
    echo "${C_GREEN}判定：健康${C_RESET} — 未见 SMART 严重字段与内核 I/O 错误记录。"
fi
echo "================================================================"
exit 0
